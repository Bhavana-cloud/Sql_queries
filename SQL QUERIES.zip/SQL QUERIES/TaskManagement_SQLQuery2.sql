

-----------------------level 1-------------------------------------------------------------


--Simple select
SELECT * FROM Employee

--select without from
select 'without using from clause' as [Message], '1001' as CodeNumber,'bhavu' as Comments

--select using variable
DECLARE @varName NVARCHAR(50), @variable INT
SET @varName = 'A new Value'
SET @variable= 03

SELECT @varName as 'using variable'
SELECT @variable as 'a value'


--use Select to assign a value to a variable 
DECLARE @var2 INT
SET @var2 = 1001
SELECT @var2 = 1002 --will not slect anything

--select top few records
SELECT TOP 1 Empid,EmpName from Employee

--Select Top newest record
--{arrange in DESC and select top record}
select * from Employee ORDER BY EmpName desc --/asc

--get the newest employee who joined
select top 1 * FROM Employee ORDER BY EmpName desc


select *from EmpTask Order By EmpId Desc
select top 5 * from EmpTask 

--get distinct records from 
--1) get distinct names of employee 

select distinct EmpName From Employee

--get distinct employeeid with name
select distinct EmpId,EmpName from Employee




-------------------Level 2-----------------------------------------------------------



--Select with where clause
select * from Employee where EmpName='Bhavana R' AND  Empid = 1000
select * from EMployee  where EmpName='Bhavana R' OR Empid = 1001
Select * from employee where EmpName <> ' Bhavana R' -- <> means not
Select top 2 * from Employee Where EmpName <> 'Bhavana R' --execution takes place from left to right

select * from Employee where EmpName IN ('Bhavana R', 'Brinda') --includes
select * from Employee where EmpName  Not IN ('Bhavana R', 'Brinda') --not include

select * from Employee where Empid BETWEEN 1002 AND 2002



------------------------------------------Level 3------------------------------------------------------------------

-- we'll use wildcards : *[used in select query]-> one or more, _->only one character, %[used in condition query]->one or more 
---use LIKE

--get all the names that start with B
select * from Employee where EmpName LIKE 'B%'

-- name ending with a
select * from employee where EmpName LIKE '%a'


----------------------------------------Level 4--------------------------------------------------------
----SUB QUERIES-----------------------

select(select EmpName from Employee where Empid = 1000) as [Emp NAme],
      (select 5+5) as [Percent hike] 

DECLARE @Empid INT
SET @Empid =(select Top 1 Empid from Employee where EmpName= 'Bhavana R')
select @Empid as [employee assigned]


DECLARE @new Int
SET @new=(select top 1 Empid from employee where EmpName = 'Brinda')
select @new

----to print a log message------
----to convert int to nvarchar use CAST------
print 'this is FINAL NUMBER '+  CAST(@new AS NVARCHAR)


--Clone a table - only its schema
select * INTO EmployeeClone from Employee where 1=0 --- where 1=0 is used to copy only schema

--create a qucik backup with schema and contents
select * INTO EmployeeBackup from Employee 

select * into empbackup from Employee where Managerid IS NOT NULL

select * from Employee  where 1=0 -- IS schema of employee without entries

---using select with more than one tables
---display all Empnames with thier corresponding tasknames 

select * from Employee as E,Task as T -- gives random data (cartesian product)(unwanted record)
--display Empnames with taskid
select E.EmpName , ET.Taskid,T.TaskName from Employee as E, EmpTask as ET,Task as T
where E.Empid = ET.Empid and ET.Taskid = T.Taskid

---display tasknames with empid
select E.Empid,T.Taskname from Employee as E, EmpTask as ET, Task as T
where ET.Taskid=T.Taskid and E.Empid=ET.Empid



--display all empnames with thier corresponding tasknames
select E.EmpName , T.Taskname from Employee as E, EmpTask as ET, Task as T
where E.Empid=Et.Empid AND ET.Taskid=T.Taskid

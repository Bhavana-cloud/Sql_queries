---Joins

select T.TaskName, ET.EmpId from Task as T INNER JOIN EmpTask as ET on T.Taskid = ET.Taskid

select * from Employee as E inner join emptask as ET on E.Empid=ET.Empid inner join Task as T on T.Taskid=ET.Taskid

select EmpName as [emp name],T.[TaskName] as [working on task] from Employee as E inner join EmpTask as ET
	on E.Empid=ET.Empid inner join Task as T
	on T.Taskid=ET.Taskid ---incorrect

select E.[Empname],ET.Taskid from Employee as E left outer join EmpTask as ET on E.Empid=ET.Empid

select E.[Empname],ET.Taskid from EmpTask as ET right outer join Employee as E on ET.Empid=E.Empid

select E.[Empname],ET.Taskid from Employee as E left outer join EmpTask as ET on E.Empid=ET.Empid

select E.[Empname],ET.Taskid from Employee as E FULL OUTER JOIN EmpTask as ET on E.Empid=ET.Empid


------------------------------------------------------------------------------------------------------------------------------

--CREATE STORED PROCEDURE

CREATE PROCEDURE sp_GetEmpTaskNames  AS
SELECT E.EmpName , T.[TaskName] From Employee as E Left outer join EmpTask as ET on E.Empid = ET.Empid left outer join Task as T on T.Taskid=ET.Taskid


---for executing stored procedure
exec sp_GetEmpTaskNames

--Alter PRocedure
ALTER PROCEDURE  sp_GetEmpTaskNames  @EmpNames Nvarchar 
 











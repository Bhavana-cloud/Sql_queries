----Lab-----

--Between--
select * from Employee where Doj BETWEEN '2023-10-01' AND '2023-11-01'

--get all names with 1 space
select * from employee where EmpName LIKE '% %'

--get all names that have the 2nd character as 'r'
select * from Employee where EmpName LIKE '_r%'


---get empname displayed as empname-empid, Eg -> Bhavana-1000
select EmpName+'-'+CAST(Empid AS NVARCHAR) AS FORMATTEDNAME FROM Employee

----------------------------------Lab1------------------------------------

--Add extra records (Around 5 more) to Task table


--Get all tasks that contain 'Coding' in it
select *from Task where TaskName='coding' 

--- Get all tasks that end by end of October
select * from Task where EndDate BETWEEN '2023-10-26' AND '2023-10-31'


--- Get all tasks that start on the same day (Eg: 25-Oct-2023)
select *from Task ORDER BY StartDate asc

---Select tasks and display in format Task Name - starts on- StartDate - ends by- End Date
--Eg:Coding-starts on-2023-10-25 00:00:00.0-ends by-2023-10-30 00:00:00.0

select TaskName+'-starts on-'+CAST(StartDate AS NVARCHAR)+'-ends by-'+CAST(EndDate AS NVARCHAR) FROM Task


---Select Tasks that start in October with Task name containing 'coding'
select * from Task where (StartDate BETWEEN '2023-10-01'AND '2023-10-31') AND TaskName = 'coding'


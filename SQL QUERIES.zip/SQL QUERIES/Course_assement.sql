--- Get count of students grouped by Institute Name

select count(S.Studentname) as cou , I.Institutename from Student as S , Institute as I 
where S.Institueid = I.Instituteid group by I.Institutename

--- Create a function to get total students in an institute. Here InstituteId is provided as the parameter

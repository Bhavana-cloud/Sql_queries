-- create template

--step 1
DECLARE c1 CURSOR FOR <select-query>

--step 2
OPEN c1

--step 3
FETCH NEXT FROM c1
INTO <variables-corresponding-to-columns-in-select-query>

--step 4
--your logic
--Use Conditions, loops, queries etc

--STEP 5
CLOSE c1

-- STEP 6
DEALLOCATE c1


--------------------------------------------------------------
--CURSOR
DECLARE @ID INT,@NAME NVARCHAR(50),@MID INT,@DOJ as Datetime
DECLARE c1 CURSOR FOR
SELECT Empid,EmpName,ManagerId,Doj FROM Employee
WHERE IsActive=1

OPEN c1
FETCH NEXT FROM c1
INTO @ID,@NAME,@MID,@DOJ

WHILE @@FETCH_STATUS=0
BEGIN
	IF @DOJ BETWEEN '2023-10-01' AND '2023-10-31'
		PRINT 'INCREMENT 10% ' +  @NAME
	ELSE IF @DOJ BETWEEN  '2023-11-01' AND '2023-11-30'
	    PRINT 'INCREMENT 20% ' + @NAME
	ELSE IF @DOJ<'2023-10-31'
		PRINT 'INCREMENT 30% ' + @NAME

FETCH NEXT FROM c1
INTO @ID,@NAME,@MID,@DOJ
END
CLOSE c1
DEALLOCATE c1
----------------------------------------------------------------------------

CREATE PROCEDURE spPrintAllIncrements
as
BEGIN
    DECLARE @ID INT,@NAME NVARCHAR(50),@MID INT,@DOJ as Datetime
	DECLARE c1 CURSOR FOR
	SELECT Empid,EmpName,ManagerId,Doj FROM Employee
	WHERE IsActive=1

	OPEN c1
	FETCH NEXT FROM c1
	INTO @ID,@NAME,@MID,@DOJ

	WHILE @@FETCH_STATUS=0
	BEGIN
		IF @DOJ BETWEEN '2023-10-01' AND '2023-10-31'
			PRINT 'INCREMENT 10% ' +  @NAME
		ELSE IF @DOJ BETWEEN  '2023-11-01' AND '2023-11-30'
			PRINT 'INCREMENT 20% ' + @NAME
		ELSE IF @DOJ<'2023-10-31'
			PRINT 'INCREMENT 30% ' + @NAME

	FETCH NEXT FROM c1
	INTO @ID,@NAME,@MID,@DOJ
	END
	CLOSE c1
	DEALLOCATE c1
END



---Requirement :Return comma - separated employee names
--analysis: sql feature:cursor,coz record-by-record processing
CREATE FUNCTION fnEmptoCsv() RETURNS nvarchar(MAX)
As
BEGIN
	DECLARE @EName NVARCHAR(MAX) , @result NVARCHAR(MAX)
	DECLARE c1 CURSOR FOR
	SELECT EmpName from employee
	
	OPEN c1
	fetch next from c1
	into @EName

	set @result = ' '
	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @result = @result + @EName +   '  ,   '
		FETCH NEXT FROM c1
			into @EName
	END

	CLOSE c1
	DEALLOCATE c1
	RETURN @result
END
GO

SELECT dbo.fnEmptoCsv()

	   



USE [dupdb]
GO
/****** Object:  UserDefinedFunction [dbo].[fnEmptoCsv]    Script Date: 30-10-2023 12:37:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[fnEmptoCsv]() RETURNS nvarchar(MAX)
As
BEGIN
	DECLARE @EName NVARCHAR(MAX),@result NVARCHAR(MAX)
	DECLARE c1 CURSOR FOR
	SELECT EmpName from employee
	
	OPEN c1
	fetch next from c1
	into @EName

	set @result = ' '
	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @result = @result + @EName + ','
		FETCH NEXT FROM c1
			into @EName
	END

	CLOSE c1
	DEALLOCATE c1
	RETURN @result
END
GO
/****** Object:  Table [dbo].[empbackup]    Script Date: 30-10-2023 12:37:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[empbackup](
	[Empid] [int] IDENTITY(1000,1) NOT NULL,
	[EmpName] [nvarchar](50) NULL,
	[Managerid] [int] NULL,
	[Emailid] [nvarchar](70) NULL,
	[IsActive] [bit] NULL,
	[Doj] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Employee]    Script Date: 30-10-2023 12:37:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Employee](
	[Empid] [int] IDENTITY(1000,1) NOT NULL,
	[EmpName] [nvarchar](50) NULL,
	[Managerid] [int] NULL,
	[Emailid] [nvarchar](70) NULL,
	[IsActive] [bit] NULL,
	[Doj] [datetime] NULL,
 CONSTRAINT [PK_Employee] PRIMARY KEY CLUSTERED 
(
	[Empid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EmployeeBackup]    Script Date: 30-10-2023 12:37:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmployeeBackup](
	[Empid] [int] IDENTITY(1000,1) NOT NULL,
	[EmpName] [nvarchar](50) NULL,
	[Managerid] [int] NULL,
	[Emailid] [nvarchar](70) NULL,
	[IsActive] [bit] NULL,
	[Doj] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EmployeeClone]    Script Date: 30-10-2023 12:37:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmployeeClone](
	[Empid] [int] IDENTITY(1000,1) NOT NULL,
	[EmpName] [nvarchar](50) NULL,
	[Managerid] [int] NULL,
	[Emailid] [nvarchar](70) NULL,
	[IsActive] [bit] NULL,
	[Doj] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EmpTask]    Script Date: 30-10-2023 12:37:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmpTask](
	[Taskid] [int] NOT NULL,
	[Empid] [int] NOT NULL,
	[IsSubmitted] [bit] NULL,
	[IsCompleted] [bit] NULL,
	[ModifiedOn] [datetime] NULL,
 CONSTRAINT [PK_EmpTask] PRIMARY KEY CLUSTERED 
(
	[Taskid] ASC,
	[Empid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Task]    Script Date: 30-10-2023 12:37:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Task](
	[Taskid] [int] IDENTITY(1,1) NOT NULL,
	[TaskName] [nvarchar](200) NULL,
	[StartDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Task] PRIMARY KEY CLUSTERED 
(
	[Taskid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[empbackup] ON 
GO
INSERT [dbo].[empbackup] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (1001, N'jhbyhiug5', 1002, N'bhjgb@gmail.com', 1, CAST(N'2023-09-08T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[empbackup] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (2002, N'abs', 1010, N'abs@gmail.com', 0, CAST(N'2023-10-30T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[empbackup] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (2003, N'brinda', 1012, N'brinda@gmail.com', 0, CAST(N'2023-10-25T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[empbackup] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (2004, N'Bhavana R', 1015, N'bhavna@gmail.com', 1, CAST(N'2023-09-10T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[empbackup] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (3001, N'keerthi', 1020, N'keerthi@gmail.com', 1, CAST(N'2023-11-15T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[empbackup] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (3002, N'kiran', 1030, N'kira@gmail.com', 0, CAST(N'2023-11-30T00:00:00.000' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[empbackup] OFF
GO
SET IDENTITY_INSERT [dbo].[Employee] ON 
GO
INSERT [dbo].[Employee] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (1000, N'Bhavana R', NULL, N'bhavna@gmail.com', 1, CAST(N'2023-09-10T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[Employee] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (1001, N'jhbyhiug5', 1002, N'bhjgb@gmail.com', 1, CAST(N'2023-09-08T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[Employee] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (2001, N'brinda', NULL, N'brinda@gmail.com', 0, CAST(N'2023-10-25T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[Employee] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (2002, N'abs', 1010, N'abs@gmail.com', 0, CAST(N'2023-10-30T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[Employee] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (2003, N'brinda', 1012, N'brinda@gmail.com', 0, CAST(N'2023-10-25T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[Employee] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (2004, N'Bhavana R', 1015, N'bhavna@gmail.com', 1, CAST(N'2023-09-10T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[Employee] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (3001, N'keerthi', 1020, N'keerthi@gmail.com', 1, CAST(N'2023-11-15T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[Employee] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (3002, N'kiran', 1030, N'kira@gmail.com', 0, CAST(N'2023-11-30T00:00:00.000' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[Employee] OFF
GO
SET IDENTITY_INSERT [dbo].[EmployeeBackup] ON 
GO
INSERT [dbo].[EmployeeBackup] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (1000, N'Bhavana R', NULL, N'bhavna@gmail.com', 1, CAST(N'2023-09-10T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[EmployeeBackup] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (1001, N'jhbyhiug5', 1002, N'bhjgb@gmail.com', 1, CAST(N'2023-09-08T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[EmployeeBackup] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (2001, N'brinda', NULL, N'brinda@gmail.com', 0, CAST(N'2023-10-25T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[EmployeeBackup] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (2002, N'abs', 1010, N'abs@gmail.com', 0, CAST(N'2023-10-30T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[EmployeeBackup] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (2003, N'brinda', 1012, N'brinda@gmail.com', 0, CAST(N'2023-10-25T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[EmployeeBackup] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (2004, N'Bhavana R', 1015, N'bhavna@gmail.com', 1, CAST(N'2023-09-10T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[EmployeeBackup] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (3001, N'keerthi', 1020, N'keerthi@gmail.com', 1, CAST(N'2023-11-15T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[EmployeeBackup] ([Empid], [EmpName], [Managerid], [Emailid], [IsActive], [Doj]) VALUES (3002, N'kiran', 1030, N'kira@gmail.com', 0, CAST(N'2023-11-30T00:00:00.000' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[EmployeeBackup] OFF
GO
INSERT [dbo].[EmpTask] ([Taskid], [Empid], [IsSubmitted], [IsCompleted], [ModifiedOn]) VALUES (1, 1000, 0, 0, CAST(N'2023-10-25T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[EmpTask] ([Taskid], [Empid], [IsSubmitted], [IsCompleted], [ModifiedOn]) VALUES (2, 1001, 0, 0, CAST(N'2023-10-25T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[EmpTask] ([Taskid], [Empid], [IsSubmitted], [IsCompleted], [ModifiedOn]) VALUES (3, 2001, 1, 1, CAST(N'2023-10-30T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[EmpTask] ([Taskid], [Empid], [IsSubmitted], [IsCompleted], [ModifiedOn]) VALUES (4, 2002, 1, 1, CAST(N'2023-11-12T01:53:00.000' AS DateTime))
GO
INSERT [dbo].[EmpTask] ([Taskid], [Empid], [IsSubmitted], [IsCompleted], [ModifiedOn]) VALUES (1005, 2003, 1, 0, CAST(N'2023-11-30T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[EmpTask] ([Taskid], [Empid], [IsSubmitted], [IsCompleted], [ModifiedOn]) VALUES (1006, 2004, 0, 1, CAST(N'2023-12-03T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[EmpTask] ([Taskid], [Empid], [IsSubmitted], [IsCompleted], [ModifiedOn]) VALUES (1007, 3001, 1, 1, CAST(N'2023-11-27T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[EmpTask] ([Taskid], [Empid], [IsSubmitted], [IsCompleted], [ModifiedOn]) VALUES (1008, 3002, 0, 0, CAST(N'2023-11-30T00:00:00.000' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[Task] ON 
GO
INSERT [dbo].[Task] ([Taskid], [TaskName], [StartDate], [EndDate]) VALUES (1, N'creating tables', CAST(N'2023-10-25T00:00:00.000' AS DateTime), CAST(N'2023-10-27T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[Task] ([Taskid], [TaskName], [StartDate], [EndDate]) VALUES (2, N'sql', CAST(N'2023-10-26T00:00:00.000' AS DateTime), CAST(N'2023-10-30T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[Task] ([Taskid], [TaskName], [StartDate], [EndDate]) VALUES (3, N'coding', CAST(N'2023-10-30T00:00:00.000' AS DateTime), CAST(N'2023-11-01T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[Task] ([Taskid], [TaskName], [StartDate], [EndDate]) VALUES (4, N'coding', CAST(N'2023-10-01T00:00:00.000' AS DateTime), CAST(N'2023-11-30T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[Task] ([Taskid], [TaskName], [StartDate], [EndDate]) VALUES (1005, N'review', CAST(N'2023-11-17T00:00:00.000' AS DateTime), CAST(N'2023-11-30T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[Task] ([Taskid], [TaskName], [StartDate], [EndDate]) VALUES (1006, N'manage', CAST(N'2023-10-25T00:00:00.000' AS DateTime), CAST(N'2023-11-30T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[Task] ([Taskid], [TaskName], [StartDate], [EndDate]) VALUES (1007, N'coding', CAST(N'2023-11-26T00:00:00.000' AS DateTime), CAST(N'2023-11-30T00:00:00.000' AS DateTime))
GO
INSERT [dbo].[Task] ([Taskid], [TaskName], [StartDate], [EndDate]) VALUES (1008, N'upload', CAST(N'2023-11-30T00:00:00.000' AS DateTime), CAST(N'2023-12-05T00:00:00.000' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[Task] OFF
GO
ALTER TABLE [dbo].[EmpTask]  WITH CHECK ADD  CONSTRAINT [FK_EmpTask_Employee] FOREIGN KEY([Empid])
REFERENCES [dbo].[Employee] ([Empid])
GO
ALTER TABLE [dbo].[EmpTask] CHECK CONSTRAINT [FK_EmpTask_Employee]
GO
ALTER TABLE [dbo].[EmpTask]  WITH CHECK ADD  CONSTRAINT [FK_EmpTask_Task] FOREIGN KEY([Taskid])
REFERENCES [dbo].[Task] ([Taskid])
GO
ALTER TABLE [dbo].[EmpTask] CHECK CONSTRAINT [FK_EmpTask_Task]
GO
/****** Object:  StoredProcedure [dbo].[spPrintAllIncrements]    Script Date: 30-10-2023 12:37:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[spPrintAllIncrements]
as
BEGIN
    DECLARE @ID INT,@NAME NVARCHAR(50),@MID INT,@DOJ as Datetime
	DECLARE c1 CURSOR FOR
	SELECT Empid,EmpName,ManagerId,Doj FROM Employee
	WHERE IsActive=1

	OPEN c1
	FETCH NEXT FROM c1
	INTO @ID,@NAME,@MID,@DOJ

	WHILE @@FETCH_STATUS=0
	BEGIN
		IF @DOJ BETWEEN '2023-10-01' AND '2023-10-31'
			PRINT 'INCREMENT 10% ' +  @NAME
		ELSE IF @DOJ BETWEEN  '2023-11-01' AND '2023-11-30'
			PRINT 'INCREMENT 20% ' + @NAME
		ELSE IF @DOJ<'2023-10-31'
			PRINT 'INCREMENT 30% ' + @NAME

	FETCH NEXT FROM c1
	INTO @ID,@NAME,@MID,@DOJ
	END
	CLOSE c1
	DEALLOCATE c1
END
GO
